<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Riwayat Transaksi';
$db = getDB();

// Filters
$search = cleanRaw($_GET['q'] ?? '');
$date_from = cleanRaw($_GET['date_from'] ?? '');
$date_to = cleanRaw($_GET['date_to'] ?? '');
$kasir_filter = (int)($_GET['kasir_id'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;

$where = "WHERE 1=1";
if ($search) $where .= " AND (t.kode LIKE '%$search%')";
if ($date_from) $where .= " AND DATE(t.created_at) >= '$date_from'";
if ($date_to) $where .= " AND DATE(t.created_at) <= '$date_to'";
if ($kasir_filter) $where .= " AND t.kasir_id=$kasir_filter";

$total = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM transaksi t $where"))['c'];
$totalPages = ceil($total / $perPage);

$transaksis = mysqli_query($db, "SELECT t.*, k.username as kasir_name FROM transaksi t JOIN kasir k ON t.kasir_id=k.id $where ORDER BY t.created_at DESC LIMIT $perPage OFFSET $offset");

$kasirList = [];
$res = mysqli_query($db, "SELECT id, username FROM kasir ORDER BY username");
while ($k = mysqli_fetch_assoc($res)) $kasirList[] = $k;

// Summary stats for filter period
$statsRes = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as cnt, COALESCE(SUM(grand_total),0) as total FROM transaksi t $where"));

include __DIR__ . '/../includes/header.php';
?>

<div class="card" style="margin-bottom:16px;">
  <div class="card-body" style="padding:14px 16px;">
    <form method="GET" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
      <div>
        <label class="form-label" style="margin-bottom:4px;">Cari Kode</label>
        <input type="text" name="q" class="form-control" placeholder="TRX-..." value="<?= htmlspecialchars($search) ?>" style="width:160px;">
      </div>
      <div>
        <label class="form-label" style="margin-bottom:4px;">Dari Tanggal</label>
        <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>" style="width:150px;">
      </div>
      <div>
        <label class="form-label" style="margin-bottom:4px;">Sampai Tanggal</label>
        <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>" style="width:150px;">
      </div>
      <div>
        <label class="form-label" style="margin-bottom:4px;">Kasir</label>
        <select name="kasir_id" class="form-control" style="width:140px;">
          <option value="">Semua Kasir</option>
          <?php foreach ($kasirList as $k): ?>
          <option value="<?= $k['id'] ?>" <?= $kasir_filter == $k['id'] ? 'selected' : '' ?>><?= htmlspecialchars($k['username']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex; gap:8px;">
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <a href="?" class="btn btn-secondary btn-sm">Reset</a>
      </div>
    </form>
  </div>
</div>

<!-- Summary -->
<div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-bottom:16px;">
  <div class="stat-card" style="padding:16px;">
    <div class="stat-value" style="font-size:1.3rem;"><?= $statsRes['cnt'] ?></div>
    <div class="stat-label">Total Transaksi</div>
  </div>
  <div class="stat-card" style="padding:16px;">
    <div class="stat-value" style="font-size:1.3rem;"><?= formatRp($statsRes['total']) ?></div>
    <div class="stat-label">Total Pendapatan</div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <span class="card-title">Daftar Transaksi</span>
    <span style="font-size:0.82rem; color:var(--text-muted);"><?= $total ?> transaksi</span>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Kode Transaksi</th>
          <th>Kasir</th>
          <th>Grand Total</th>
          <th>Dibayar</th>
          <th>Kembalian</th>
          <th>Waktu</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($t = mysqli_fetch_assoc($transaksis)): ?>
        <tr>
          <td><span class="sku-tag"><?= htmlspecialchars($t['kode']) ?></span></td>
          <td><?= htmlspecialchars($t['kasir_name']) ?></td>
          <td style="font-family:'Playfair Display',serif; font-weight:700; color:var(--gold-dark);"><?= formatRp($t['grand_total']) ?></td>
          <td style="font-family:'Playfair Display',serif;"><?= formatRp($t['amount_paid']) ?></td>
          <td style="color:var(--green); font-weight:500;"><?= formatRp($t['change_amount']) ?></td>
          <td style="font-size:0.8rem; color:var(--text-muted); white-space:nowrap;"><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="btn btn-sm btn-outline" onclick="viewDetail(<?= $t['id'] ?>)">Detail</button>
              <a href="<?= BASE_URL ?>/pages/struk_pdf.php?trx_id=<?= $t['id'] ?>" class="btn btn-sm btn-secondary" target="_blank">PDF</a>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
        <?php if ($total === 0): ?>
        <tr><td colspan="7"><div class="empty-state"><div class="empty-icon">≡</div><h3>Tidak ada transaksi</h3></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  
  <?php if ($totalPages > 1): ?>
  <div style="padding:16px 20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; border-top:1px solid var(--border-light);">
    <span style="font-size:0.82rem; color:var(--text-muted);">Showing <?= ($offset+1) ?>–<?= min($offset+$perPage, $total) ?> of <?= $total ?></span>
    <div class="pagination">
      <?php
      $baseUrl = '?' . http_build_query(array_filter(['q'=>$search,'date_from'=>$date_from,'date_to'=>$date_to,'kasir_id'=>$kasir_filter?:null]));
      for ($i=1; $i<=$totalPages; $i++):
      ?>
      <a href="<?= $baseUrl ?>&page=<?= $i ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- Modal Detail Transaksi -->
<div class="modal-overlay" id="modalDetail">
  <div class="modal modal-lg">
    <div class="modal-header">
      <span class="modal-title">Detail Transaksi</span>
      <button class="modal-close" onclick="closeModal('modalDetail')">✕</button>
    </div>
    <div class="modal-body" id="modalDetailBody">
      <div style="text-align:center; padding:20px;"><span class="loading"></span></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalDetail')">Tutup</button>
      <button class="btn btn-primary" id="modalPdfBtn" onclick="">⬇ Download PDF</button>
    </div>
  </div>
</div>

<?php
$extraScript = '<script>
function viewDetail(trxId) {
  document.getElementById("modalDetailBody").innerHTML = \'<div style="text-align:center;padding:20px;"><span class="loading"></span></div>\';
  document.getElementById("modalPdfBtn").onclick = function() { window.open("<?= BASE_URL ?>/pages/struk_pdf.php?trx_id=" + trxId, "_blank"); };
  openModal("modalDetail");
  
  fetch("<?= BASE_URL ?>/pages/trx_detail.php?id=" + trxId)
    .then(function(r){ return r.text(); })
    .then(function(html) {
      document.getElementById("modalDetailBody").innerHTML = html;
    });
}
</script>';
include __DIR__ . '/../includes/footer.php';
?>
