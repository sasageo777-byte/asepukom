# Doks Store — Point of Sale System

Aplikasi POS (Point of Sale) untuk minimarket **Doks Store**, Jatiawsie.

## Stack
- **PHP 7.2** Native (no framework, mysqli)
- **MySQL 5.7**
- **Apache2** (Ubuntu 18.04)
- **HTML/CSS/JS** Native

## Fitur
- ✅ Kasir / POS dengan input SKU (scan/ketik)
- ✅ Manajemen Produk (CRUD + SKU otomatis)
- ✅ Manajemen Kategori (dengan alias 3 char untuk SKU)
- ✅ Riwayat Transaksi (filter, detail, print/download struk)
- ✅ Manajemen Kasir (daftar, CRUD)
- ✅ Auth (login, registrasi tanpa secret)
- ✅ Profile + Edit Profile (halaman terpisah)
- ✅ Print/Download PDF Struk
- ✅ Responsive (mobile-friendly)
- ✅ Tema Classic Luxury Light

## Akun Default
| Username | Password  |
|----------|-----------|
| admin    | password  |

## Format SKU
`ALIAS_KATEGORI-NamaProduk-Berat`

Contoh: `MIN-AquaBottle-600`, `MKN-IndomieGoreng-85`

## Cara Jalankan dengan Docker

```bash
docker-compose up -d
```

Akses:
- App: http://localhost:8080
- phpMyAdmin: http://localhost:8081

## Cara Jalankan dengan XAMPP

1. Copy folder ke `htdocs/doks-store`
2. Import `database.sql` ke phpMyAdmin
3. Edit `config.php` jika perlu (DB credentials)
4. Akses: http://localhost/doks-store/

## Struktur Folder
```
doks-store/
├── assets/
│   └── css/style.css
├── includes/
│   ├── header.php
│   └── footer.php
├── pages/
│   ├── dashboard.php
│   ├── kasir.php         ← POS utama
│   ├── produk.php
│   ├── kategori.php
│   ├── riwayat.php
│   ├── akun.php
│   ├── profile.php       ← View profile
│   ├── profile_edit.php  ← Edit profile
│   ├── struk_pdf.php     ← Print/download struk
│   ├── trx_detail.php    ← AJAX detail transaksi
│   └── logout.php
├── config.php
├── index.php             ← Login/Register
├── database.sql
├── Dockerfile
└── docker-compose.yml
```
