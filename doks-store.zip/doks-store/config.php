<?php
// Doks Store - Configuration
define('APP_NAME', 'Doks Store');
define('APP_LOCATION', 'Jatiawsie');
define('APP_VERSION', '1.0.0');

// Database
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'doks_store_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
define('BASE_URL', $protocol . '://' . $host);

// Session
session_start();

// DB Connection (mysqli)
function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            die(json_encode(['error' => 'Database connection failed: ' . mysqli_connect_error()]));
        }
        mysqli_set_charset($conn, 'utf8mb4');
    }
    return $conn;
}

// Auth helpers
function isLoggedIn() {
    return isset($_SESSION['kasir_id']) && !empty($_SESSION['kasir_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function getCurrentKasir() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $id = (int)$_SESSION['kasir_id'];
    $res = mysqli_query($db, "SELECT id, username, email FROM kasir WHERE id = $id");
    return mysqli_fetch_assoc($res);
}

// Format currency
function formatRp($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

// Sanitize
function clean($str) {
    $db = getDB();
    return mysqli_real_escape_string($db, htmlspecialchars(strip_tags(trim($str))));
}

function cleanRaw($str) {
    $db = getDB();
    return mysqli_real_escape_string($db, trim($str));
}

// Generate transaction code
function generateTrxCode() {
    $db = getDB();
    $date = date('Ymd');
    $res = mysqli_query($db, "SELECT COUNT(*) as cnt FROM transaksi WHERE DATE(created_at) = CURDATE()");
    $row = mysqli_fetch_assoc($res);
    $seq = str_pad($row['cnt'] + 1, 4, '0', STR_PAD_LEFT);
    return "TRX-{$date}-{$seq}";
}
?>
