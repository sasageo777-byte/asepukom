<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$db = getDB();

$id = (int)($_GET['trx_id'] ?? 0);
if (!$id) { http_response_code(404); die('Transaksi tidak ditemukan.'); }

$trx = mysqli_fetch_assoc(mysqli_query($db, "SELECT t.*, k.username as kasir_name FROM transaksi t JOIN kasir k ON t.kasir_id=k.id WHERE t.id=$id"));
if (!$trx) { http_response_code(404); die('Transaksi tidak ditemukan.'); }

$details = mysqli_query($db, "SELECT * FROM transaksi_detail WHERE transaksi_id=$id ORDER BY id ASC");
$detailsList = [];
while ($d = mysqli_fetch_assoc($details)) $detailsList[] = $d;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Struk - <?= htmlspecialchars($trx['kode']) ?></title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Courier New', monospace; font-size: 12px; background: white; padding: 20px; }
  .receipt { max-width: 320px; margin: 0 auto; }
  .receipt-header { text-align: center; margin-bottom: 10px; }
  .store-name { font-size: 16px; font-weight: bold; }
  .divider { border-top: 1px dashed #999; margin: 8px 0; }
  .row { display: flex; justify-content: space-between; margin: 2px 0; }
  .bold { font-weight: bold; }
  .footer { text-align: center; margin-top: 10px; font-style: italic; }
  .item-name { font-weight: bold; }
  .item-detail { margin-left: 10px; }
  
  @media print {
    body { padding: 0; }
    .no-print { display: none; }
    @page { margin: 5mm; size: 80mm auto; }
  }
</style>
</head>
<body>
<div class="no-print" style="text-align:center; margin-bottom:20px; padding:10px; background:#f5f5f5; border-radius:4px;">
  <button onclick="window.print()" style="padding:8px 20px; background:#C9A84C; color:white; border:none; border-radius:4px; cursor:pointer; font-size:14px; margin-right:10px;">🖨 Print</button>
  <button onclick="window.close()" style="padding:8px 16px; background:#ccc; border:none; border-radius:4px; cursor:pointer; font-size:14px;">Tutup</button>
</div>

<div class="receipt">
  <div class="receipt-header">
    <div class="store-name"><?= APP_NAME ?></div>
    <div><?= APP_LOCATION ?></div>
    <div style="font-size:10px;">Kasir: <?= htmlspecialchars($trx['kasir_name']) ?></div>
  </div>
  
  <div class="divider"></div>
  
  <div class="row"><span>Kode</span><span><?= htmlspecialchars($trx['kode']) ?></span></div>
  <div class="row"><span>Tanggal</span><span><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></span></div>
  
  <div class="divider"></div>
  
  <?php foreach ($detailsList as $d): ?>
  <div class="item-name"><?= htmlspecialchars($d['produk_name']) ?></div>
  <div class="row item-detail">
    <span><?= $d['qty'] ?> x Rp <?= number_format($d['harga_satuan'], 0, ',', '.') ?><?= $d['discount'] > 0 ? ' (-'.$d['discount'].'%)' : '' ?></span>
    <span>Rp <?= number_format($d['subtotal'], 0, ',', '.') ?></span>
  </div>
  <?php endforeach; ?>
  
  <div class="divider"></div>
  
  <div class="row bold"><span>TOTAL</span><span>Rp <?= number_format($trx['grand_total'], 0, ',', '.') ?></span></div>
  <div class="row"><span>Bayar</span><span>Rp <?= number_format($trx['amount_paid'], 0, ',', '.') ?></span></div>
  <div class="row"><span>Kembali</span><span>Rp <?= number_format($trx['change_amount'], 0, ',', '.') ?></span></div>
  
  <div class="divider"></div>
  
  <div class="footer">
    Terima kasih telah berbelanja!<br>
    <?= APP_NAME ?><br>
    <?= date('d/m/Y H:i:s', strtotime($trx['created_at'])) ?>
  </div>
</div>

<script>
// Auto print if opened from POS
if (window.opener) {
  window.onload = function() { window.print(); };
}
</script>
</body>
</html>
