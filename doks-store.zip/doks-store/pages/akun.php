<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Daftar Kasir';
$db = getDB();
$currentKasirId = (int)$_SESSION['kasir_id'];

$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $username = cleanRaw($_POST['username'] ?? '');
        $email = cleanRaw($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'Semua field wajib diisi.';
        } elseif (strlen($username) < 3) {
            $error = 'Username minimal 3 karakter.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Format email tidak valid.';
        } elseif (strlen($password) < 6) {
            $error = 'Password minimal 6 karakter.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM kasir WHERE username='$username' OR email='$email'");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                mysqli_query($db, "INSERT INTO kasir (username, email, password) VALUES ('$username', '$email', '$hash')");
                $success = 'Akun kasir berhasil ditambahkan.';
            }
        }
    } elseif ($action === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $username = cleanRaw($_POST['username'] ?? '');
        $email = cleanRaw($_POST['email'] ?? '');
        $newpass = $_POST['new_password'] ?? '';
        
        if (empty($username) || empty($email)) {
            $error = 'Username dan email wajib diisi.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Format email tidak valid.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM kasir WHERE (username='$username' OR email='$email') AND id != $id");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                if (!empty($newpass)) {
                    if (strlen($newpass) < 6) {
                        $error = 'Password baru minimal 6 karakter.';
                    } else {
                        $hash = password_hash($newpass, PASSWORD_DEFAULT);
                        mysqli_query($db, "UPDATE kasir SET username='$username', email='$email', password='$hash' WHERE id=$id");
                        $success = 'Akun kasir berhasil diperbarui.';
                    }
                } else {
                    mysqli_query($db, "UPDATE kasir SET username='$username', email='$email' WHERE id=$id");
                    $success = 'Akun kasir berhasil diperbarui.';
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id === $currentKasirId) {
            $error = 'Tidak bisa menghapus akun yang sedang aktif.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM transaksi WHERE kasir_id=$id LIMIT 1");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Kasir masih memiliki riwayat transaksi, tidak bisa dihapus.';
            } else {
                mysqli_query($db, "DELETE FROM kasir WHERE id=$id");
                $success = 'Akun kasir berhasil dihapus.';
            }
        }
    }
}

$search = cleanRaw($_GET['q'] ?? '');
$where = $search ? "WHERE username LIKE '%$search%' OR email LIKE '%$search%'" : '';
$kasirs = mysqli_query($db, "SELECT k.*, (SELECT COUNT(*) FROM transaksi t WHERE t.kasir_id=k.id) as trx_count FROM kasir k $where ORDER BY k.username ASC");

include __DIR__ . '/../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="card">
  <div class="card-header">
    <span class="card-title">Daftar Kasir</span>
    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
      <form method="GET" style="display:flex; gap:8px;">
        <input type="text" name="q" class="form-control" placeholder="Cari username / email..." value="<?= htmlspecialchars($search) ?>" style="width:200px;">
        <button type="submit" class="btn btn-secondary btn-sm">Cari</button>
        <?php if ($search): ?><a href="?" class="btn btn-secondary btn-sm">Reset</a><?php endif; ?>
      </form>
      <button class="btn btn-primary btn-sm" onclick="openModal('modalAdd')">+ Tambah Kasir</button>
    </div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr><th>#</th><th>Username</th><th>Email</th><th>Transaksi</th><th>Bergabung</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php $no=1; while ($k = mysqli_fetch_assoc($kasirs)): ?>
        <tr>
          <td style="color:var(--text-muted);"><?= $no++ ?></td>
          <td>
            <div style="display:flex; align-items:center; gap:10px;">
              <div class="user-avatar" style="width:30px; height:30px; font-size:0.75rem; background:<?= $k['id']==$currentKasirId ? 'var(--gold)' : 'var(--brown-light)' ?>;">
                <?= strtoupper(substr($k['username'], 0, 1)) ?>
              </div>
              <div>
                <div style="font-weight:600;"><?= htmlspecialchars($k['username']) ?></div>
                <?php if ($k['id'] == $currentKasirId): ?>
                <div><span class="badge badge-gold" style="font-size:0.65rem;">Anda</span></div>
                <?php endif; ?>
              </div>
            </div>
          </td>
          <td style="color:var(--text-muted);"><?= htmlspecialchars($k['email']) ?></td>
          <td><?= $k['trx_count'] ?> transaksi</td>
          <td style="font-size:0.8rem; color:var(--text-muted);"><?= date('d/m/Y', strtotime($k['created_at'])) ?></td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="btn btn-sm btn-outline" onclick="openEditModal(<?= $k['id'] ?>, '<?= addslashes(htmlspecialchars($k['username'])) ?>', '<?= addslashes(htmlspecialchars($k['email'])) ?>')">Edit</button>
              <?php if ($k['id'] !== $currentKasirId): ?>
              <form method="POST" onsubmit="return confirm('Hapus kasir <?= addslashes(htmlspecialchars($k['username'])) ?>?');" style="display:inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $k['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
        <?php if ($no === 1): ?>
        <tr><td colspan="6"><div class="empty-state"><div class="empty-icon">◯</div><h3>Tidak ada kasir</h3></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Add -->
<div class="modal-overlay" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Tambah Kasir</span>
      <button class="modal-close" onclick="closeModal('modalAdd')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" placeholder="Minimal 3 karakter" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" placeholder="email@contoh.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalAdd')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal-overlay" id="modalEdit">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Edit Kasir</span>
      <button class="modal-close" onclick="closeModal('modalEdit')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="editId">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" id="editUsername" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" id="editEmail" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password Baru <span style="font-size:0.75rem; color:var(--text-muted);">(kosongkan jika tidak diubah)</span></label>
          <input type="password" name="new_password" class="form-control" placeholder="Isi untuk ganti password">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalEdit')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
      </div>
    </form>
  </div>
</div>

<?php
$extraScript = '<script>
function openEditModal(id, username, email) {
  document.getElementById("editId").value = id;
  document.getElementById("editUsername").value = username;
  document.getElementById("editEmail").value = email;
  openModal("modalEdit");
}
</script>';
include __DIR__ . '/../includes/footer.php';
?>
