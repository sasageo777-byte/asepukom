<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Dashboard';
$db = getDB();

// Stats
$totalProduk = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM produk"))['c'];
$totalKategori = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM kategori"))['c'];
$totalKasir = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM kasir"))['c'];

$todayRevenue = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(grand_total),0) as t FROM transaksi WHERE DATE(created_at) = CURDATE()"))['t'];
$todayTrx = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM transaksi WHERE DATE(created_at) = CURDATE()"))['c'];
$monthRevenue = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(grand_total),0) as t FROM transaksi WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())"))['t'];
$totalRevenue = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(grand_total),0) as t FROM transaksi"))['t'];

// Recent transactions
$recentTrx = mysqli_query($db, "SELECT t.*, k.username as kasir_name FROM transaksi t JOIN kasir k ON t.kasir_id=k.id ORDER BY t.created_at DESC LIMIT 8");

// Low stock products
$lowStock = mysqli_query($db, "SELECT p.*, k.nama as kategori_name FROM produk p JOIN kategori k ON p.kategori_id=k.id WHERE p.stock <= 5 ORDER BY p.stock ASC LIMIT 6");

// Top sold
$topSold = mysqli_query($db, "SELECT p.*, k.nama as kategori_name FROM produk p JOIN kategori k ON p.kategori_id=k.id ORDER BY p.sold DESC LIMIT 5");

include __DIR__ . '/../includes/header.php';
?>

<!-- Stats -->
<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-icon">⊞</div>
    <div class="stat-value"><?= formatRp($todayRevenue) ?></div>
    <div class="stat-label">Pendapatan Hari Ini</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">◈</div>
    <div class="stat-value"><?= $todayTrx ?></div>
    <div class="stat-label">Transaksi Hari Ini</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">◻</div>
    <div class="stat-value"><?= formatRp($monthRevenue) ?></div>
    <div class="stat-label">Pendapatan Bulan Ini</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">≡</div>
    <div class="stat-value"><?= $totalProduk ?></div>
    <div class="stat-label">Total Produk</div>
  </div>
</div>

<div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:20px;">

  <!-- Recent Transactions -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">Transaksi Terbaru</span>
      <a href="<?= BASE_URL ?>/pages/riwayat.php" class="btn btn-sm btn-secondary">Lihat Semua</a>
    </div>
    <?php if (mysqli_num_rows($recentTrx) > 0): ?>
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Kode</th>
            <th>Kasir</th>
            <th>Total</th>
            <th>Waktu</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($trx = mysqli_fetch_assoc($recentTrx)): ?>
          <tr>
            <td><span class="sku-tag"><?= htmlspecialchars($trx['kode']) ?></span></td>
            <td><?= htmlspecialchars($trx['kasir_name']) ?></td>
            <td style="font-family:'Playfair Display',serif; color:var(--gold-dark); font-weight:700;"><?= formatRp($trx['grand_total']) ?></td>
            <td style="font-size:0.78rem; color:var(--text-muted);"><?= date('d/m H:i', strtotime($trx['created_at'])) ?></td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">≡</div>
      <h3>Belum Ada Transaksi</h3>
    </div>
    <?php endif; ?>
  </div>

  <!-- Top Sold -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">Produk Terlaris</span>
    </div>
    <?php if (mysqli_num_rows($topSold) > 0): ?>
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>Produk</th><th>Terjual</th><th>Stok</th></tr>
        </thead>
        <tbody>
          <?php while ($p = mysqli_fetch_assoc($topSold)): ?>
          <tr>
            <td>
              <div style="font-weight:600; font-size:0.84rem;"><?= htmlspecialchars($p['name']) ?></div>
              <div class="sku-tag" style="margin-top:2px;"><?= htmlspecialchars($p['sku']) ?></div>
            </td>
            <td><span class="badge badge-gold"><?= $p['sold'] ?> terjual</span></td>
            <td><?= $p['stock'] <= 5 ? '<span class="badge badge-red">' . $p['stock'] . '</span>' : '<span class="badge badge-green">' . $p['stock'] . '</span>' ?></td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">◻</div>
      <h3>Belum Ada Data</h3>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Low Stock Warning -->
<?php if (mysqli_num_rows($lowStock) > 0): ?>
<div class="card">
  <div class="card-header">
    <span class="card-title" style="color:var(--red);">⚠ Stok Menipis</span>
    <span style="font-size:0.8rem; color:var(--text-muted);">Produk dengan stok ≤ 5</span>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr><th>Produk</th><th>SKU</th><th>Kategori</th><th>Stok</th></tr>
      </thead>
      <tbody>
        <?php while ($p = mysqli_fetch_assoc($lowStock)): ?>
        <tr>
          <td style="font-weight:600;"><?= htmlspecialchars($p['name']) ?></td>
          <td><span class="sku-tag"><?= htmlspecialchars($p['sku']) ?></span></td>
          <td><?= htmlspecialchars($p['kategori_name']) ?></td>
          <td><span class="badge badge-red"><?= $p['stock'] ?></span></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
