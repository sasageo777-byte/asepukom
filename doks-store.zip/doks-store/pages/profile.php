<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Profile Saya';
$db = getDB();
$kasir = getCurrentKasir();
$id = $kasir['id'];

// Stats
$trxCount = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM transaksi WHERE kasir_id=$id"))['c'];
$totalRevenue = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(grand_total),0) as t FROM transaksi WHERE kasir_id=$id"))['t'];
$todayTrx = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM transaksi WHERE kasir_id=$id AND DATE(created_at)=CURDATE()"))['c'];
$recentTrx = mysqli_query($db, "SELECT * FROM transaksi WHERE kasir_id=$id ORDER BY created_at DESC LIMIT 5");
$joinDate = mysqli_fetch_assoc(mysqli_query($db, "SELECT created_at FROM kasir WHERE id=$id"))['created_at'];

include __DIR__ . '/../includes/header.php';
?>

<div style="display:grid; grid-template-columns: 340px 1fr; gap:20px; align-items:start;">
  
  <!-- Profile Card -->
  <div>
    <div class="card" style="text-align:center; padding:32px 24px;">
      <div style="width:80px; height:80px; background:linear-gradient(135deg, var(--gold), var(--gold-dark)); border-radius:50%; display:flex; align-items:center; justify-content:center; font-family:'Playfair Display',serif; font-size:2rem; font-weight:700; color:white; margin:0 auto 16px;">
        <?= strtoupper(substr($kasir['username'], 0, 1)) ?>
      </div>
      <h2 style="font-family:'Playfair Display',serif; font-size:1.4rem; margin-bottom:4px;"><?= htmlspecialchars($kasir['username']) ?></h2>
      <p style="color:var(--text-muted); font-size:0.85rem; margin-bottom:4px;"><?= htmlspecialchars($kasir['email']) ?></p>
      <p style="font-size:0.78rem; color:var(--text-light);">Bergabung: <?= date('d F Y', strtotime($joinDate)) ?></p>
      
      <div class="gold-divider" style="margin:20px 0;"></div>
      
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; text-align:center;">
        <div style="background:var(--cream); border-radius:var(--radius); padding:12px;">
          <div style="font-family:'Playfair Display',serif; font-size:1.4rem; font-weight:700; color:var(--gold-dark);"><?= $trxCount ?></div>
          <div style="font-size:0.72rem; color:var(--text-muted);">Total Transaksi</div>
        </div>
        <div style="background:var(--cream); border-radius:var(--radius); padding:12px;">
          <div style="font-family:'Playfair Display',serif; font-size:1.4rem; font-weight:700; color:var(--gold-dark);"><?= $todayTrx ?></div>
          <div style="font-size:0.72rem; color:var(--text-muted);">Transaksi Hari Ini</div>
        </div>
      </div>
      
      <div style="background:var(--cream); border-radius:var(--radius); padding:12px; margin-top:12px; text-align:center;">
        <div style="font-size:0.72rem; color:var(--text-muted); margin-bottom:2px;">Total Omzet</div>
        <div style="font-family:'Playfair Display',serif; font-size:1.1rem; font-weight:700; color:var(--gold-dark);"><?= formatRp($totalRevenue) ?></div>
      </div>
      
      <a href="<?= BASE_URL ?>/pages/profile_edit.php" class="btn btn-primary" style="width:100%; justify-content:center; margin-top:16px;">
        ✎ Edit Profile
      </a>
    </div>
  </div>
  
  <!-- Recent Activity -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">Transaksi Terakhir Saya</span>
      <a href="<?= BASE_URL ?>/pages/riwayat.php?kasir_id=<?= $id ?>" class="btn btn-sm btn-secondary">Lihat Semua</a>
    </div>
    <?php if (mysqli_num_rows($recentTrx) > 0): ?>
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>Kode</th><th>Grand Total</th><th>Bayar</th><th>Kembali</th><th>Waktu</th><th>Aksi</th></tr>
        </thead>
        <tbody>
          <?php while ($t = mysqli_fetch_assoc($recentTrx)): ?>
          <tr>
            <td><span class="sku-tag"><?= htmlspecialchars($t['kode']) ?></span></td>
            <td style="font-family:'Playfair Display',serif; font-weight:700; color:var(--gold-dark);"><?= formatRp($t['grand_total']) ?></td>
            <td style="font-family:'Playfair Display',serif;"><?= formatRp($t['amount_paid']) ?></td>
            <td style="color:var(--green);"><?= formatRp($t['change_amount']) ?></td>
            <td style="font-size:0.8rem; color:var(--text-muted);"><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
            <td>
              <a href="<?= BASE_URL ?>/pages/struk_pdf.php?trx_id=<?= $t['id'] ?>" class="btn btn-sm btn-outline" target="_blank">Struk</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">≡</div>
      <h3>Belum ada transaksi</h3>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php
$extraScript = '';
include __DIR__ . '/../includes/footer.php';
?>
