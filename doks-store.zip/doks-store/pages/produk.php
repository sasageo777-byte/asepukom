<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Produk';
$db = getDB();

$error = ''; $success = '';

// Helper: build SKU
function buildSku($alias, $name, $berat) {
    $namePart = preg_replace('/\s+/', '', ucwords(strtolower($name)));
    $namePart = preg_replace('/[^a-zA-Z0-9]/', '', $namePart);
    return strtoupper($alias) . '-' . $namePart . '-' . intval($berat);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $name = cleanRaw($_POST['name'] ?? '');
        $kategori_id = (int)($_POST['kategori_id'] ?? 0);
        $berat = (int)($_POST['berat'] ?? 0);
        $price = floatval($_POST['price'] ?? 0);
        $discount = floatval($_POST['discount'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        
        if (empty($name) || !$kategori_id || !$berat || !$price) {
            $error = 'Nama, kategori, berat, dan harga wajib diisi.';
        } elseif ($discount < 0 || $discount > 100) {
            $error = 'Diskon harus antara 0–100%.';
        } else {
            // Get alias
            $katRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT alias FROM kategori WHERE id=$kategori_id"));
            if (!$katRow) { $error = 'Kategori tidak ditemukan.'; }
            else {
                $sku = buildSku($katRow['alias'], $name, $berat);
                if ($action === 'add') {
                    $chk = mysqli_query($db, "SELECT id FROM produk WHERE sku='$sku'");
                    if (mysqli_num_rows($chk) > 0) {
                        $error = "SKU '$sku' sudah ada. Ubah nama atau berat.";
                    } else {
                        mysqli_query($db, "INSERT INTO produk (name, sku, discount, kategori_id, berat, price, stock) VALUES ('$name', '$sku', $discount, $kategori_id, $berat, $price, $stock)");
                        $success = "Produk berhasil ditambahkan. SKU: $sku";
                    }
                } else {
                    $id = (int)($_POST['id'] ?? 0);
                    $chk = mysqli_query($db, "SELECT id FROM produk WHERE sku='$sku' AND id != $id");
                    if (mysqli_num_rows($chk) > 0) {
                        $error = "SKU '$sku' sudah digunakan produk lain.";
                    } else {
                        mysqli_query($db, "UPDATE produk SET name='$name', sku='$sku', discount=$discount, kategori_id=$kategori_id, berat=$berat, price=$price, stock=$stock WHERE id=$id");
                        $success = 'Produk berhasil diperbarui.';
                    }
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $chk = mysqli_query($db, "SELECT id FROM transaksi_detail WHERE produk_id=$id LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = 'Produk sudah pernah terjual, tidak bisa dihapus.';
        } else {
            mysqli_query($db, "DELETE FROM produk WHERE id=$id");
            $success = 'Produk berhasil dihapus.';
        }
    }
}

// Filters
$search = cleanRaw($_GET['q'] ?? '');
$kat_filter = (int)($_GET['kat'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

$where = "WHERE 1=1";
if ($search) $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%')";
if ($kat_filter) $where .= " AND p.kategori_id=$kat_filter";

$total = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM produk p $where"))['c'];
$totalPages = ceil($total / $perPage);
$products = mysqli_query($db, "SELECT p.*, k.nama as kategori_name, k.alias FROM produk p JOIN kategori k ON p.kategori_id=k.id $where ORDER BY p.name ASC LIMIT $perPage OFFSET $offset");

$kategoris = mysqli_query($db, "SELECT * FROM kategori ORDER BY nama ASC");
$katList = [];
while ($k = mysqli_fetch_assoc($kategoris)) $katList[] = $k;

include __DIR__ . '/../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="card">
  <div class="card-header">
    <span class="card-title">Daftar Produk</span>
    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
      <form method="GET" style="display:flex; gap:8px; flex-wrap:wrap;">
        <input type="text" name="q" class="form-control" placeholder="Cari produk / SKU..." value="<?= htmlspecialchars($search) ?>" style="width:180px;">
        <select name="kat" class="form-control" style="width:140px;">
          <option value="">Semua Kategori</option>
          <?php foreach ($katList as $k): ?>
          <option value="<?= $k['id'] ?>" <?= $kat_filter == $k['id'] ? 'selected' : '' ?>><?= htmlspecialchars($k['nama']) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
        <?php if ($search || $kat_filter): ?><a href="?" class="btn btn-secondary btn-sm">Reset</a><?php endif; ?>
      </form>
      <button class="btn btn-primary btn-sm" onclick="openModal('modalAdd')">+ Tambah Produk</button>
    </div>
  </div>
  
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>#</th><th>Nama Produk</th><th>SKU</th><th>Kategori</th>
          <th>Berat</th><th>Harga</th><th>Diskon</th><th>Stok</th><th>Terjual</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = $offset+1; while ($p = mysqli_fetch_assoc($products)): 
          $finalPrice = $p['price'] * (1 - $p['discount']/100);
        ?>
        <tr>
          <td style="color:var(--text-muted);"><?= $no++ ?></td>
          <td style="font-weight:600; min-width:140px;"><?= htmlspecialchars($p['name']) ?></td>
          <td><span class="sku-tag"><?= htmlspecialchars($p['sku']) ?></span></td>
          <td><span class="badge badge-blue"><?= htmlspecialchars($p['kategori_name']) ?></span></td>
          <td><?= number_format($p['berat']) ?>g</td>
          <td style="font-family:'Playfair Display',serif; white-space:nowrap;">
            <?php if ($p['discount'] > 0): ?>
            <span style="text-decoration:line-through; color:var(--text-light); font-size:0.78rem;"><?= formatRp($p['price']) ?></span><br>
            <span style="color:var(--gold-dark); font-weight:700;"><?= formatRp($finalPrice) ?></span>
            <?php else: ?>
            <?= formatRp($p['price']) ?>
            <?php endif; ?>
          </td>
          <td><?= $p['discount'] > 0 ? '<span class="badge badge-red">'.$p['discount'].'%</span>' : '<span class="badge badge-gray">0%</span>' ?></td>
          <td><?= $p['stock'] <= 5 ? '<span class="badge badge-red">'.$p['stock'].'</span>' : '<span class="badge badge-green">'.$p['stock'].'</span>' ?></td>
          <td><?= $p['sold'] ?></td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="btn btn-sm btn-outline" onclick="openEditModal(<?= htmlspecialchars(json_encode($p)) ?>)">Edit</button>
              <form method="POST" onsubmit="return confirm('Hapus produk ini?');" style="display:inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
        <?php if ($no === $offset+1): ?>
        <tr><td colspan="10"><div class="empty-state"><div class="empty-icon">◻</div><h3>Tidak ada produk</h3></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  
  <?php if ($totalPages > 1): ?>
  <div style="padding:16px 20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; border-top:1px solid var(--border-light);">
    <span style="font-size:0.82rem; color:var(--text-muted);">Showing <?= ($offset+1) ?>–<?= min($offset+$perPage, $total) ?> of <?= $total ?></span>
    <div class="pagination">
      <?php
      $baseUrl = '?' . http_build_query(array_filter(['q'=>$search,'kat'=>$kat_filter?:null]));
      for ($i=1; $i<=$totalPages; $i++):
      ?>
      <a href="<?= $baseUrl ?>&page=<?= $i ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- Modal Add -->
<div class="modal-overlay" id="modalAdd">
  <div class="modal modal-lg">
    <div class="modal-header">
      <span class="modal-title">Tambah Produk</span>
      <button class="modal-close" onclick="closeModal('modalAdd')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Produk</label>
          <input type="text" name="name" id="addName" class="form-control" placeholder="Contoh: Aqua Botol" required oninput="previewSku('add')">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Kategori</label>
            <select name="kategori_id" id="addKat" class="form-control" required onchange="previewSku('add')">
              <option value="">Pilih Kategori</option>
              <?php foreach ($katList as $k): ?>
              <option value="<?= $k['id'] ?>" data-alias="<?= $k['alias'] ?>"><?= htmlspecialchars($k['nama']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Berat (gram)</label>
            <input type="number" name="berat" id="addBerat" class="form-control" placeholder="Contoh: 600" min="1" required oninput="previewSku('add')">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Preview SKU</label>
          <div id="addSkuPreview" class="sku-tag" style="display:inline-block; font-size:0.88rem; padding:6px 12px;">—</div>
          <span class="form-hint">SKU otomatis dibuat dari Alias Kategori + Nama + Berat</span>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Harga (Rp)</label>
            <input type="number" name="price" class="form-control" placeholder="0" min="0" step="100" required>
          </div>
          <div class="form-group">
            <label class="form-label">Diskon (%)</label>
            <input type="number" name="discount" class="form-control" value="0" min="0" max="100" step="0.01">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Stok</label>
          <input type="number" name="stock" class="form-control" value="0" min="0" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalAdd')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan Produk</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal-overlay" id="modalEdit">
  <div class="modal modal-lg">
    <div class="modal-header">
      <span class="modal-title">Edit Produk</span>
      <button class="modal-close" onclick="closeModal('modalEdit')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="editId">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Produk</label>
          <input type="text" name="name" id="editName" class="form-control" required oninput="previewSku('edit')">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Kategori</label>
            <select name="kategori_id" id="editKat" class="form-control" required onchange="previewSku('edit')">
              <option value="">Pilih Kategori</option>
              <?php foreach ($katList as $k): ?>
              <option value="<?= $k['id'] ?>" data-alias="<?= $k['alias'] ?>"><?= htmlspecialchars($k['nama']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Berat (gram)</label>
            <input type="number" name="berat" id="editBerat" class="form-control" min="1" required oninput="previewSku('edit')">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Preview SKU</label>
          <div id="editSkuPreview" class="sku-tag" style="display:inline-block; font-size:0.88rem; padding:6px 12px;">—</div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Harga (Rp)</label>
            <input type="number" name="price" id="editPrice" class="form-control" min="0" step="100" required>
          </div>
          <div class="form-group">
            <label class="form-label">Diskon (%)</label>
            <input type="number" name="discount" id="editDiscount" class="form-control" min="0" max="100" step="0.01">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Stok</label>
          <input type="number" name="stock" id="editStock" class="form-control" min="0" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalEdit')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
      </div>
    </form>
  </div>
</div>

<?php
$extraScript = '<script>
function buildSkuPreview(alias, name, berat) {
  if (!alias || !name || !berat) return "—";
  var namePart = name.replace(/\s+/g, "");
  namePart = namePart.replace(/[^a-zA-Z0-9]/g, "");
  namePart = namePart.charAt(0).toUpperCase() + namePart.slice(1);
  return alias.toUpperCase() + "-" + namePart + "-" + parseInt(berat);
}

function previewSku(prefix) {
  var nameEl = document.getElementById(prefix + "Name");
  var katEl = document.getElementById(prefix + "Kat");
  var beratEl = document.getElementById(prefix + "Berat");
  var previewEl = document.getElementById(prefix + "SkuPreview");
  if (!nameEl || !katEl || !beratEl || !previewEl) return;
  var selOpt = katEl.options[katEl.selectedIndex];
  var alias = selOpt ? selOpt.getAttribute("data-alias") || "" : "";
  previewEl.textContent = buildSkuPreview(alias, nameEl.value, beratEl.value);
}

function openEditModal(p) {
  document.getElementById("editId").value = p.id;
  document.getElementById("editName").value = p.name;
  document.getElementById("editBerat").value = p.berat;
  document.getElementById("editPrice").value = p.price;
  document.getElementById("editDiscount").value = p.discount;
  document.getElementById("editStock").value = p.stock;
  var sel = document.getElementById("editKat");
  for (var i = 0; i < sel.options.length; i++) {
    if (sel.options[i].value == p.kategori_id) { sel.selectedIndex = i; break; }
  }
  previewSku("edit");
  openModal("modalEdit");
}
</script>';
include __DIR__ . "/../includes/footer.php";
?>
