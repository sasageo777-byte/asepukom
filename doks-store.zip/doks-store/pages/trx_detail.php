<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$db = getDB();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo '<p>ID tidak valid.</p>'; exit; }

$trx = mysqli_fetch_assoc(mysqli_query($db, "SELECT t.*, k.username as kasir_name FROM transaksi t JOIN kasir k ON t.kasir_id=k.id WHERE t.id=$id"));
if (!$trx) { echo '<p>Transaksi tidak ditemukan.</p>'; exit; }

$details = mysqli_query($db, "SELECT * FROM transaksi_detail WHERE transaksi_id=$id ORDER BY id ASC");
?>
<div>
  <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px;">
    <div>
      <div style="font-size:0.78rem; color:var(--text-muted);">Kode Transaksi</div>
      <div style="font-weight:700; font-size:1rem;"><?= htmlspecialchars($trx['kode']) ?></div>
    </div>
    <div>
      <div style="font-size:0.78rem; color:var(--text-muted);">Kasir</div>
      <div style="font-weight:600;"><?= htmlspecialchars($trx['kasir_name']) ?></div>
    </div>
    <div>
      <div style="font-size:0.78rem; color:var(--text-muted);">Tanggal</div>
      <div><?= date('d/m/Y H:i:s', strtotime($trx['created_at'])) ?></div>
    </div>
  </div>
  
  <div class="gold-divider" style="margin-bottom:12px;"></div>
  
  <div class="table-wrapper">
    <table>
      <thead>
        <tr><th>Produk</th><th>SKU</th><th>Harga</th><th>Diskon</th><th>Qty</th><th>Subtotal</th></tr>
      </thead>
      <tbody>
        <?php while ($d = mysqli_fetch_assoc($details)): ?>
        <tr>
          <td style="font-weight:600;"><?= htmlspecialchars($d['produk_name']) ?></td>
          <td><span class="sku-tag"><?= htmlspecialchars($d['produk_sku']) ?></span></td>
          <td style="font-family:'Playfair Display',serif;"><?= formatRp($d['harga_satuan']) ?></td>
          <td><?= $d['discount'] > 0 ? '<span class="badge badge-red">'.$d['discount'].'%</span>' : '—' ?></td>
          <td><?= $d['qty'] ?></td>
          <td style="font-family:'Playfair Display',serif; font-weight:700; color:var(--gold-dark);"><?= formatRp($d['subtotal']) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  
  <div class="gold-divider" style="margin:12px 0;"></div>
  
  <div style="display:flex; flex-direction:column; gap:6px; align-items:flex-end;">
    <div style="display:flex; gap:40px; font-size:0.88rem; color:var(--text-muted);">
      <span>Grand Total</span>
      <span style="font-family:'Playfair Display',serif; font-weight:700; color:var(--text-main); font-size:1rem;"><?= formatRp($trx['grand_total']) ?></span>
    </div>
    <div style="display:flex; gap:40px; font-size:0.88rem; color:var(--text-muted);">
      <span>Dibayar</span>
      <span style="font-family:'Playfair Display',serif;"><?= formatRp($trx['amount_paid']) ?></span>
    </div>
    <div style="display:flex; gap:40px; font-size:0.88rem; color:var(--text-muted);">
      <span>Kembalian</span>
      <span style="font-family:'Playfair Display',serif; color:var(--green); font-weight:600;"><?= formatRp($trx['change_amount']) ?></span>
    </div>
  </div>
</div>
