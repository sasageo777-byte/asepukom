<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Kasir / POS';
$db = getDB();
$kasir = getCurrentKasir();

// Handle checkout (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    header('Content-Type: application/json');
    $items = json_decode($_POST['items'] ?? '[]', true);
    $amountPaid = floatval($_POST['amount_paid'] ?? 0);
    
    if (empty($items)) { echo json_encode(['success'=>false,'msg'=>'Keranjang kosong.']); exit; }
    
    // Validate & calculate
    $grandTotal = 0;
    $details = [];
    foreach ($items as $item) {
        $pid = (int)($item['id'] ?? 0);
        $qty = (int)($item['qty'] ?? 0);
        if ($pid <= 0 || $qty <= 0) continue;
        
        $pRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM produk WHERE id=$pid"));
        if (!$pRow) { echo json_encode(['success'=>false,'msg'=>"Produk ID $pid tidak ditemukan."]); exit; }
        if ($pRow['stock'] < $qty) { echo json_encode(['success'=>false,'msg'=>"Stok {$pRow['name']} tidak cukup. Stok: {$pRow['stock']}"]); exit; }
        
        $finalPrice = $pRow['price'] * (1 - $pRow['discount']/100);
        $subtotal = $finalPrice * $qty;
        $grandTotal += $subtotal;
        $details[] = ['produk'=>$pRow, 'qty'=>$qty, 'harga'=>$finalPrice, 'subtotal'=>$subtotal];
    }
    
    if ($amountPaid < $grandTotal) { echo json_encode(['success'=>false,'msg'=>'Uang bayar kurang.']); exit; }
    
    $change = $amountPaid - $grandTotal;
    $kode = generateTrxCode();
    $kasirId = (int)$_SESSION['kasir_id'];
    
    mysqli_query($db, "INSERT INTO transaksi (kode, kasir_id, grand_total, amount_paid, change_amount) VALUES ('$kode', $kasirId, $grandTotal, $amountPaid, $change)");
    $trxId = mysqli_insert_id($db);
    
    foreach ($details as $d) {
        $p = $d['produk'];
        $pId = $p['id'];
        $pName = mysqli_real_escape_string($db, $p['name']);
        $pSku = mysqli_real_escape_string($db, $p['sku']);
        $disc = floatval($p['discount']);
        $harga = $d['harga'];
        $qty = $d['qty'];
        $sub = $d['subtotal'];
        mysqli_query($db, "INSERT INTO transaksi_detail (transaksi_id, produk_id, produk_name, produk_sku, harga_satuan, discount, qty, subtotal) VALUES ($trxId, $pId, '$pName', '$pSku', $harga, $disc, $qty, $sub)");
        mysqli_query($db, "UPDATE produk SET stock=stock-$qty, sold=sold+$qty WHERE id=$pId");
    }
    
    echo json_encode(['success'=>true,'trx_id'=>$trxId,'kode'=>$kode,'grand_total'=>$grandTotal,'amount_paid'=>$amountPaid,'change'=>$change]);
    exit;
}

// Handle product lookup by SKU (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['sku_lookup'])) {
    header('Content-Type: application/json');
    $sku = cleanRaw($_GET['sku_lookup']);
    $res = mysqli_query($db, "SELECT p.*, k.nama as kategori_name FROM produk p JOIN kategori k ON p.kategori_id=k.id WHERE p.sku='$sku' LIMIT 1");
    $p = mysqli_fetch_assoc($res);
    if ($p) {
        $p['final_price'] = $p['price'] * (1 - $p['discount']/100);
        echo json_encode(['success'=>true,'product'=>$p]);
    } else {
        echo json_encode(['success'=>false,'msg'=>'Produk dengan SKU tersebut tidak ditemukan.']);
    }
    exit;
}

// Handle product search (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search_prod'])) {
    header('Content-Type: application/json');
    $q = cleanRaw($_GET['search_prod']);
    $kat = (int)($_GET['kat_id'] ?? 0);
    $where = "WHERE (p.name LIKE '%$q%' OR p.sku LIKE '%$q%')";
    if ($kat) $where .= " AND p.kategori_id=$kat";
    $res = mysqli_query($db, "SELECT p.*, k.nama as kategori_name FROM produk p JOIN kategori k ON p.kategori_id=k.id $where ORDER BY p.name ASC LIMIT 30");
    $products = [];
    while ($p = mysqli_fetch_assoc($res)) {
        $p['final_price'] = $p['price'] * (1 - $p['discount']/100);
        $products[] = $p;
    }
    echo json_encode(['success'=>true,'products'=>$products]);
    exit;
}

// Load initial products
$initProducts = mysqli_query($db, "SELECT p.*, k.nama as kategori_name FROM produk p JOIN kategori k ON p.kategori_id=k.id ORDER BY p.name ASC LIMIT 30");
$initProductsList = [];
while ($p = mysqli_fetch_assoc($initProducts)) {
    $p['final_price'] = $p['price'] * (1 - $p['discount']/100);
    $initProductsList[] = $p;
}

$kategoris = mysqli_query($db, "SELECT * FROM kategori ORDER BY nama ASC");
$katList = [];
while ($k = mysqli_fetch_assoc($kategoris)) $katList[] = $k;

include __DIR__ . '/../includes/header.php';
?>

<style>
.pos-layout { display: grid; grid-template-columns: 1fr 370px; gap: 16px; align-items: start; }
.pos-left { min-width: 0; }
.pos-right { position: sticky; top: 70px; }
@media (max-width: 992px) {
  .pos-layout { grid-template-columns: 1fr; }
  .pos-right { position: relative; top: 0; order: -1; }
}
.cart-empty { text-align:center; padding:30px 20px; color:var(--text-light); font-size:0.84rem; }
</style>

<div class="pos-layout">
  <!-- LEFT: Products -->
  <div class="pos-left">
    <!-- Search bar -->
    <div class="card" style="margin-bottom:14px;">
      <div class="card-body" style="padding:14px 16px;">
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
          <input type="text" id="skuInput" class="form-control" placeholder="Scan / ketik SKU lalu Enter..." style="flex:1; min-width:180px;" autocomplete="off">
          <input type="text" id="searchInput" class="form-control" placeholder="Cari nama produk..." style="flex:1; min-width:160px;" autocomplete="off">
          <select id="katFilter" class="form-control" style="width:140px; flex-shrink:0;">
            <option value="">Semua Kategori</option>
            <?php foreach ($katList as $k): ?>
            <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div id="skuMsg" style="margin-top:8px; display:none;"></div>
      </div>
    </div>
    
    <!-- Product Grid -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">Produk</span>
        <span id="productCount" style="font-size:0.82rem; color:var(--text-muted);"></span>
      </div>
      <div class="card-body" style="max-height:calc(100vh - 280px); overflow-y:auto; padding:14px;">
        <div class="product-grid" id="productGrid">
          <!-- Rendered by JS -->
        </div>
      </div>
    </div>
  </div>
  
  <!-- RIGHT: Cart -->
  <div class="pos-right">
    <div class="card">
      <div class="card-header">
        <span class="card-title">🛒 Keranjang</span>
        <button class="btn btn-sm btn-danger" id="clearCartBtn" onclick="clearCart()" style="display:none;">Kosongkan</button>
      </div>
      <div style="max-height:45vh; overflow-y:auto; padding:12px; border-bottom:1px solid var(--border-light);" id="cartItemsWrapper">
        <div class="cart-empty" id="cartEmpty">Keranjang kosong</div>
        <div id="cartItems" style="display:none;"></div>
      </div>
      
      <!-- Cart Summary -->
      <div style="padding:14px 16px;">
        <div class="cart-total-row">
          <span>Subtotal</span>
          <span id="sumSubtotal">Rp 0</span>
        </div>
        <div class="cart-total-row">
          <span>Diskon</span>
          <span id="sumDiskon" style="color:var(--red);">-Rp 0</span>
        </div>
        <div class="gold-divider"></div>
        <div class="cart-total-row grand" style="margin-top:6px;">
          <span>Grand Total</span>
          <span class="amount" id="sumTotal">Rp 0</span>
        </div>
        
        <div class="cart-pay-section">
          <label style="font-size:0.82rem; font-weight:500; color:var(--text-main); margin-bottom:6px; display:block;">Uang Bayar</label>
          <div class="pay-input-wrap">
            <span class="currency-symbol">Rp</span>
            <input type="number" id="amountPaid" class="pay-input" placeholder="0" min="0" oninput="updateChange()">
          </div>
          
          <!-- Quick amount buttons -->
          <div style="display:flex; gap:6px; margin-bottom:10px; flex-wrap:wrap;">
            <button class="btn btn-sm btn-outline" onclick="setQuickAmount(0)">Pas</button>
            <button class="btn btn-sm btn-outline" onclick="setQuickAmount(50000)">50rb</button>
            <button class="btn btn-sm btn-outline" onclick="setQuickAmount(100000)">100rb</button>
            <button class="btn btn-sm btn-outline" onclick="setQuickAmount(200000)">200rb</button>
          </div>
          
          <div class="change-display" id="changeDisplay" style="display:none;">
            <span>Kembalian</span>
            <span class="change-amount" id="changeAmount">Rp 0</span>
          </div>
          
          <button class="btn-checkout" id="checkoutBtn" onclick="doCheckout()" disabled>Bayar</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Struk -->
<div class="modal-overlay" id="modalStruk">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Transaksi Berhasil</span>
      <button class="modal-close" onclick="closeModal('modalStruk')">✕</button>
    </div>
    <div class="modal-body">
      <div class="receipt" id="receiptContent"></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal('modalStruk'); resetPos();">Transaksi Baru</button>
      <button class="btn btn-primary" onclick="printReceipt()">🖨 Print Struk</button>
      <button class="btn btn-outline" onclick="downloadPdfReceipt()">⬇ Download PDF</button>
    </div>
  </div>
</div>

<script>
var allProducts = <?= json_encode($initProductsList) ?>;
var cart = {}; // { prodId: { product: {}, qty: int } }
var lastTrxData = null;

// Format currency
function fmtRp(n) {
  return 'Rp ' + Number(n).toLocaleString('id-ID');
}

// Render product grid
function renderProducts(products) {
  var grid = document.getElementById('productGrid');
  var countEl = document.getElementById('productCount');
  if (!products || products.length === 0) {
    grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><div class="empty-icon">◻</div><h3>Produk tidak ditemukan</h3></div>';
    countEl.textContent = '0 produk';
    return;
  }
  countEl.textContent = products.length + ' produk';
  var html = '';
  products.forEach(function(p) {
    var outOfStock = parseInt(p.stock) <= 0;
    var discBadge = parseFloat(p.discount) > 0 ? '<span class="product-discount-badge">-'+p.discount+'%</span>' : '';
    html += '<div class="product-card' + (outOfStock ? ' out-of-stock' : '') + '" onclick="addToCart(' + p.id + ')">';
    html += discBadge;
    html += '<div class="product-card-name">' + escHtml(p.name) + '</div>';
    html += '<div class="product-card-sku">' + escHtml(p.sku) + '</div>';
    html += '<div class="product-card-price">' + fmtRp(p.final_price) + '</div>';
    html += '<div class="product-card-stock">Stok: ' + p.stock + '</div>';
    html += '</div>';
  });
  grid.innerHTML = html;
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Add to cart
function addToCart(prodId) {
  var p = allProducts.find(function(x){ return x.id == prodId; });
  if (!p) {
    // Product not in current list, find from server
    fetch('kasir.php?sku_lookup=&prod_id=' + prodId).then(function(r){return r.json();}).then(function(d){
      if (d.success) {
        allProducts.push(d.product);
        addToCartObj(d.product);
      }
    });
    return;
  }
  addToCartObj(p);
}

function addToCartObj(p) {
  if (parseInt(p.stock) <= 0) {
    showMsg('Stok produk habis.', 'error');
    return;
  }
  var pid = p.id;
  if (cart[pid]) {
    var newQty = cart[pid].qty + 1;
    var maxStock = parseInt(p.stock);
    if (newQty > maxStock) {
      showMsg('Stok tidak cukup (maks: ' + maxStock + ')', 'warning');
      return;
    }
    cart[pid].qty = newQty;
  } else {
    cart[pid] = { product: p, qty: 1 };
  }
  renderCart();
}

function updateCartQty(pid, delta) {
  if (!cart[pid]) return;
  var newQty = cart[pid].qty + delta;
  if (newQty <= 0) {
    delete cart[pid];
  } else {
    var maxStock = parseInt(cart[pid].product.stock);
    if (newQty > maxStock) {
      showMsg('Stok tidak cukup (maks: ' + maxStock + ')', 'warning');
      return;
    }
    cart[pid].qty = newQty;
  }
  renderCart();
}

function removeFromCart(pid) {
  delete cart[pid];
  renderCart();
}

function clearCart() {
  cart = {};
  renderCart();
}

function renderCart() {
  var cartItems = document.getElementById('cartItems');
  var cartEmpty = document.getElementById('cartEmpty');
  var clearBtn = document.getElementById('clearCartBtn');
  var checkoutBtn = document.getElementById('checkoutBtn');
  
  var keys = Object.keys(cart);
  if (keys.length === 0) {
    cartItems.style.display = 'none';
    cartEmpty.style.display = 'block';
    clearBtn.style.display = 'none';
    checkoutBtn.disabled = true;
    updateSummary(0, 0);
    return;
  }
  
  cartEmpty.style.display = 'none';
  cartItems.style.display = 'block';
  clearBtn.style.display = 'inline-flex';
  checkoutBtn.disabled = false;
  
  var html = '';
  var subtotalRaw = 0;
  var discountTotal = 0;
  
  keys.forEach(function(pid) {
    var item = cart[pid];
    var p = item.product;
    var finalPrice = parseFloat(p.final_price);
    var originalPrice = parseFloat(p.price);
    var qty = item.qty;
    var subtotal = finalPrice * qty;
    var origSubtotal = originalPrice * qty;
    subtotalRaw += origSubtotal;
    discountTotal += (origSubtotal - subtotal);
    
    html += '<div class="cart-item">';
    html += '<button class="cart-item-remove" onclick="removeFromCart(' + pid + ')">✕</button>';
    html += '<div class="cart-item-name">' + escHtml(p.name) + '</div>';
    html += '<div class="cart-item-sku">' + escHtml(p.sku) + '</div>';
    html += '<div class="cart-item-controls">';
    html += '<div class="qty-control">';
    html += '<button class="qty-btn" onclick="updateCartQty(' + pid + ', -1)">−</button>';
    html += '<span class="qty-value">' + qty + '</span>';
    html += '<button class="qty-btn" onclick="updateCartQty(' + pid + ', 1)">+</button>';
    html += '</div>';
    html += '<span class="cart-item-subtotal">' + fmtRp(subtotal) + '</span>';
    html += '</div>';
    html += '</div>';
  });
  
  cartItems.innerHTML = html;
  updateSummary(subtotalRaw, discountTotal);
  updateChange();
}

function updateSummary(subtotalRaw, discountTotal) {
  var grandTotal = subtotalRaw - discountTotal;
  document.getElementById('sumSubtotal').textContent = fmtRp(subtotalRaw);
  document.getElementById('sumDiskon').textContent = '-' + fmtRp(discountTotal);
  document.getElementById('sumTotal').textContent = fmtRp(grandTotal);
}

function getGrandTotal() {
  var txt = document.getElementById('sumTotal').textContent;
  var num = parseFloat(txt.replace(/[^0-9]/g, ''));
  return isNaN(num) ? 0 : num;
}

function updateChange() {
  var paid = parseFloat(document.getElementById('amountPaid').value) || 0;
  var total = getGrandTotal();
  var changeDisp = document.getElementById('changeDisplay');
  var changeAmt = document.getElementById('changeAmount');
  var checkoutBtn = document.getElementById('checkoutBtn');
  
  if (total > 0 && paid >= total) {
    var change = paid - total;
    changeAmt.textContent = fmtRp(change);
    changeDisp.style.display = 'flex';
    checkoutBtn.disabled = Object.keys(cart).length === 0;
  } else {
    changeDisp.style.display = 'none';
    checkoutBtn.disabled = true;
    if (Object.keys(cart).length > 0 && total > 0) {
      checkoutBtn.disabled = paid < total;
    }
  }
}

function setQuickAmount(extra) {
  var total = getGrandTotal();
  if (extra === 0) {
    document.getElementById('amountPaid').value = total;
  } else {
    var rounded = Math.ceil(total / extra) * extra;
    if (rounded < total) rounded += extra;
    document.getElementById('amountPaid').value = rounded > total ? rounded : extra;
  }
  updateChange();
}

// SKU input
document.getElementById('skuInput').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') {
    var sku = this.value.trim();
    if (!sku) return;
    // Check in allProducts first
    var found = allProducts.find(function(x){ return x.sku === sku; });
    if (found) {
      addToCartObj(found);
      showMsg('Produk ditambahkan: ' + found.name, 'success');
      this.value = '';
      return;
    }
    // Fetch from server
    var self = this;
    fetch('kasir.php?sku_lookup=' + encodeURIComponent(sku))
      .then(function(r){ return r.json(); })
      .then(function(d) {
        if (d.success) {
          allProducts.push(d.product);
          addToCartObj(d.product);
          showMsg('Produk ditambahkan: ' + d.product.name, 'success');
        } else {
          showMsg('SKU tidak ditemukan: ' + sku, 'error');
        }
      });
    self.value = '';
  }
});

// Search input
var searchTimer;
document.getElementById('searchInput').addEventListener('input', function() {
  clearTimeout(searchTimer);
  var q = this.value.trim();
  var kat = document.getElementById('katFilter').value;
  searchTimer = setTimeout(function() { searchProducts(q, kat); }, 300);
});

document.getElementById('katFilter').addEventListener('change', function() {
  var q = document.getElementById('searchInput').value.trim();
  searchProducts(q, this.value);
});

function searchProducts(q, kat) {
  if (!q && !kat) {
    renderProducts(allProducts);
    return;
  }
  fetch('kasir.php?search_prod=' + encodeURIComponent(q) + '&kat_id=' + encodeURIComponent(kat))
    .then(function(r){ return r.json(); })
    .then(function(d) {
      if (d.success) renderProducts(d.products);
    });
}

function showMsg(msg, type) {
  var el = document.getElementById('skuMsg');
  el.style.display = 'block';
  el.className = 'alert alert-' + (type === 'error' ? 'error' : type === 'warning' ? 'warning' : 'success');
  el.textContent = msg;
  clearTimeout(el._timer);
  el._timer = setTimeout(function() { el.style.display = 'none'; }, 3000);
}

// Checkout
function doCheckout() {
  var keys = Object.keys(cart);
  if (keys.length === 0) { showMsg('Keranjang kosong.', 'error'); return; }
  var total = getGrandTotal();
  var paid = parseFloat(document.getElementById('amountPaid').value) || 0;
  if (paid < total) { showMsg('Uang bayar kurang dari total.', 'error'); return; }
  
  var items = keys.map(function(pid) {
    return { id: parseInt(pid), qty: cart[pid].qty };
  });
  
  var fd = new FormData();
  fd.append('action', 'checkout');
  fd.append('items', JSON.stringify(items));
  fd.append('amount_paid', paid);
  
  var btn = document.getElementById('checkoutBtn');
  btn.disabled = true;
  btn.textContent = 'Memproses...';
  
  fetch('kasir.php', { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(d) {
      btn.textContent = 'Bayar';
      if (d.success) {
        lastTrxData = d;
        showReceipt(d);
      } else {
        showMsg(d.msg || 'Gagal checkout.', 'error');
        btn.disabled = false;
      }
    })
    .catch(function() {
      btn.disabled = false;
      btn.textContent = 'Bayar';
      showMsg('Error koneksi.', 'error');
    });
}

function showReceipt(d) {
  var cartItems = Object.values(cart);
  var now = new Date();
  var dateStr = now.toLocaleDateString('id-ID', {day:'2-digit',month:'2-digit',year:'numeric'});
  var timeStr = now.toLocaleTimeString('id-ID', {hour:'2-digit',minute:'2-digit'});
  
  var html = '<div class="receipt-header">';
  html += '<div class="receipt-store-name"><?= APP_NAME ?></div>';
  html += '<div><?= APP_LOCATION ?></div>';
  html += '<div style="font-size:0.75rem; margin-top:4px;">Kasir: <?= htmlspecialchars($kasir['username']) ?></div>';
  html += '</div>';
  html += '<div class="receipt-divider"></div>';
  html += '<div class="receipt-row"><span>Kode</span><span>' + d.kode + '</span></div>';
  html += '<div class="receipt-row"><span>Tanggal</span><span>' + dateStr + ' ' + timeStr + '</span></div>';
  html += '<div class="receipt-divider"></div>';
  
  cartItems.forEach(function(item) {
    var p = item.product;
    var finalP = parseFloat(p.final_price);
    html += '<div>' + p.name + '</div>';
    html += '<div class="receipt-row"><span>  ' + item.qty + ' x ' + fmtRp(finalP) + '</span><span>' + fmtRp(finalP * item.qty) + '</span></div>';
  });
  
  html += '<div class="receipt-divider"></div>';
  html += '<div class="receipt-total-row"><span>TOTAL</span><span>' + fmtRp(d.grand_total) + '</span></div>';
  html += '<div class="receipt-row"><span>Bayar</span><span>' + fmtRp(d.amount_paid) + '</span></div>';
  html += '<div class="receipt-row"><span>Kembali</span><span>' + fmtRp(d.change) + '</span></div>';
  html += '<div class="receipt-divider"></div>';
  html += '<div class="receipt-footer">Terima kasih telah berbelanja!<br><?= APP_NAME ?></div>';
  
  document.getElementById('receiptContent').innerHTML = html;
  openModal('modalStruk');
}

function resetPos() {
  cart = {};
  renderCart();
  document.getElementById('amountPaid').value = '';
  document.getElementById('changeDisplay').style.display = 'none';
  document.getElementById('skuInput').focus();
  // Refresh product list stock
  fetch('kasir.php?search_prod=&kat_id=')
    .then(function(r){ return r.json(); })
    .then(function(d) {
      if (d.success) { allProducts = d.products; renderProducts(allProducts); }
    });
}

function printReceipt() {
  var content = document.getElementById('receiptContent').innerHTML;
  var win = window.open('', '_blank', 'width=400,height=600');
  win.document.write('<html><head><title>Struk - ' + (lastTrxData ? lastTrxData.kode : '') + '</title>');
  win.document.write('<style>body{font-family:"Courier New",monospace;padding:20px;max-width:320px;} .receipt-row{display:flex;justify-content:space-between;} .receipt-total-row{display:flex;justify-content:space-between;font-weight:700;} .receipt-header{text-align:center;margin-bottom:12px;} .receipt-store-name{font-size:1.1rem;font-weight:700;} .receipt-divider{border-top:1px dashed #999;margin:8px 0;} .receipt-footer{text-align:center;margin-top:12px;font-style:italic;}</style>');
  win.document.write('</head><body>' + content + '</body></html>');
  win.document.close();
  win.print();
}

function downloadPdfReceipt() {
  if (!lastTrxData) return;
  window.location.href = '<?= BASE_URL ?>/pages/struk_pdf.php?trx_id=' + lastTrxData.trx_id;
}

// Init
renderProducts(allProducts);
document.getElementById('amountPaid').addEventListener('input', updateChange);
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
