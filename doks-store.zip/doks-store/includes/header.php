<?php
if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config.php';
}
requireLogin();
$kasir = getCurrentKasir();
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$parentDir = basename(dirname($_SERVER['PHP_SELF']));
if ($parentDir === 'pages') {
    $currentPage = basename($_SERVER['PHP_SELF'], '.php');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — ' : '' ?><?= APP_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-wrapper">
  <!-- Sidebar Overlay -->
  <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
  
  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <span class="brand-name"><?= APP_NAME ?></span>
      <span class="brand-loc"><?= APP_LOCATION ?></span>
    </div>
    
    <nav class="sidebar-nav">
      <div class="nav-section-label">Utama</div>
      <a href="<?= BASE_URL ?>/pages/dashboard.php" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
        <span class="nav-icon">◈</span> Dashboard
      </a>
      <a href="<?= BASE_URL ?>/pages/kasir.php" class="nav-item <?= $currentPage === 'kasir' ? 'active' : '' ?>">
        <span class="nav-icon">⊞</span> Kasir / POS
      </a>
      
      <div class="nav-section-label" style="margin-top:8px">Manajemen</div>
      <a href="<?= BASE_URL ?>/pages/produk.php" class="nav-item <?= $currentPage === 'produk' ? 'active' : '' ?>">
        <span class="nav-icon">◻</span> Produk
      </a>
      <a href="<?= BASE_URL ?>/pages/kategori.php" class="nav-item <?= $currentPage === 'kategori' ? 'active' : '' ?>">
        <span class="nav-icon">◈</span> Kategori
      </a>
      <a href="<?= BASE_URL ?>/pages/riwayat.php" class="nav-item <?= $currentPage === 'riwayat' ? 'active' : '' ?>">
        <span class="nav-icon">≡</span> Riwayat Transaksi
      </a>
      
      <div class="nav-section-label" style="margin-top:8px">Akun</div>
      <a href="<?= BASE_URL ?>/pages/akun.php" class="nav-item <?= $currentPage === 'akun' ? 'active' : '' ?>">
        <span class="nav-icon">⊕</span> Daftar Kasir
      </a>
      <a href="<?= BASE_URL ?>/pages/profile.php" class="nav-item <?= $currentPage === 'profile' ? 'active' : '' ?>">
        <span class="nav-icon">◯</span> Profile Saya
      </a>
    </nav>
    
    <div class="sidebar-footer">
      <div class="sidebar-user">
        <div class="user-avatar"><?= strtoupper(substr($kasir['username'], 0, 1)) ?></div>
        <div class="user-info">
          <div class="user-name"><?= htmlspecialchars($kasir['username']) ?></div>
          <div class="user-role">Kasir</div>
        </div>
      </div>
      <form method="POST" action="<?= BASE_URL ?>/pages/logout.php">
        <button type="submit" class="btn-logout">⏻ Keluar</button>
      </form>
    </div>
  </aside>
  
  <!-- Main -->
  <div class="main-content">
    <div class="topbar">
      <div class="topbar-left">
        <button class="btn-menu-toggle" onclick="toggleSidebar()" id="menuToggle">☰</button>
        <span class="page-title"><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : APP_NAME ?></span>
      </div>
      <div class="topbar-right">
        <span class="topbar-date" id="topbarDate"></span>
      </div>
    </div>
    <div class="content-area">
