<?php
require_once __DIR__ . '/config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/pages/dashboard.php');
    exit;
}

$error = '';
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = getDB();
    
    if (isset($_POST['action']) && $_POST['action'] === 'login') {
        $username = cleanRaw($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            $error = 'Username dan password wajib diisi.';
        } else {
            $res = mysqli_query($db, "SELECT * FROM kasir WHERE username = '$username' LIMIT 1");
            $user = mysqli_fetch_assoc($res);
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['kasir_id'] = $user['id'];
                $_SESSION['kasir_username'] = $user['username'];
                header('Location: ' . BASE_URL . '/pages/dashboard.php');
                exit;
            } else {
                $error = 'Username atau password salah.';
            }
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'register') {
        $tab = 'register';
        $username = cleanRaw($_POST['reg_username'] ?? '');
        $email = cleanRaw($_POST['reg_email'] ?? '');
        $password = $_POST['reg_password'] ?? '';
        $confirm = $_POST['reg_confirm'] ?? '';
        
        if (empty($username) || empty($email) || empty($password) || empty($confirm)) {
            $error = 'Semua field wajib diisi.';
        } elseif (strlen($username) < 3) {
            $error = 'Username minimal 3 karakter.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Format email tidak valid.';
        } elseif ($password !== $confirm) {
            $error = 'Password tidak cocok.';
        } elseif (strlen($password) < 6) {
            $error = 'Password minimal 6 karakter.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM kasir WHERE username='$username' OR email='$email'");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                mysqli_query($db, "INSERT INTO kasir (username, email, password) VALUES ('$username', '$email', '$hash')");
                if (mysqli_affected_rows($db) > 0) {
                    $success = 'Akun berhasil dibuat! Silakan login.';
                    $tab = 'login';
                } else {
                    $error = 'Gagal membuat akun. Coba lagi.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= APP_NAME ?> — Login</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div class="login-logo">
      <span class="store-name"><?= APP_NAME ?></span>
      <span class="store-subtitle"><?= APP_LOCATION ?> · Point of Sale</span>
      <div class="login-divider"></div>
    </div>
    
    <?php if (!empty($error)): ?>
      <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (!empty($success)): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    
    <div class="tabs">
      <button class="tab-btn <?= $tab === 'login' ? 'active' : '' ?>" onclick="switchTab('login')">Masuk</button>
      <button class="tab-btn <?= $tab === 'register' ? 'active' : '' ?>" onclick="switchTab('register')">Daftar</button>
    </div>
    
    <!-- Login Tab -->
    <div class="tab-content <?= $tab === 'login' ? 'active' : '' ?>" id="tab-login">
      <form method="POST">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" placeholder="Masukkan username" required autofocus>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-lg" style="width:100%; justify-content:center; margin-top:8px;">
          Masuk
        </button>
      </form>
    </div>
    
    <!-- Register Tab -->
    <div class="tab-content <?= $tab === 'register' ? 'active' : '' ?>" id="tab-register">
      <form method="POST">
        <input type="hidden" name="action" value="register">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="reg_username" class="form-control" placeholder="Minimal 3 karakter" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="reg_email" class="form-control" placeholder="email@contoh.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="reg_password" class="form-control" placeholder="Minimal 6 karakter" required>
        </div>
        <div class="form-group">
          <label class="form-label">Konfirmasi Password</label>
          <input type="password" name="reg_confirm" class="form-control" placeholder="Ulangi password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-lg" style="width:100%; justify-content:center; margin-top:8px;">
          Daftar Akun
        </button>
      </form>
    </div>
    
    <p style="text-align:center; margin-top:20px; font-size:0.78rem; color:var(--text-light); font-family:'Cormorant Garamond',serif;">
      &copy; <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.
    </p>
  </div>
</div>

<script>
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(function(btn, i) {
    btn.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'));
  });
  document.getElementById('tab-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-register').classList.toggle('active', tab === 'register');
}
</script>
</body>
</html>
