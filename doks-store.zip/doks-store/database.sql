-- Doks Store Database
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";

CREATE DATABASE IF NOT EXISTS `doks_store_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `doks_store_db`;

-- Table: kasir
CREATE TABLE `kasir` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: kategori
CREATE TABLE `kategori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `alias` char(3) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: produk
CREATE TABLE `produk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `discount` decimal(5,2) DEFAULT 0.00,
  `kategori_id` int(11) NOT NULL,
  `berat` int(11) NOT NULL DEFAULT 0,
  `price` decimal(15,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `sold` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `kategori_id` (`kategori_id`),
  CONSTRAINT `fk_produk_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: transaksi
CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(30) NOT NULL,
  `kasir_id` int(11) NOT NULL,
  `grand_total` decimal(15,2) NOT NULL,
  `amount_paid` decimal(15,2) NOT NULL,
  `change_amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode` (`kode`),
  KEY `kasir_id` (`kasir_id`),
  CONSTRAINT `fk_transaksi_kasir` FOREIGN KEY (`kasir_id`) REFERENCES `kasir` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: transaksi_detail
CREATE TABLE `transaksi_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaksi_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `produk_name` varchar(200) NOT NULL,
  `produk_sku` varchar(50) NOT NULL,
  `harga_satuan` decimal(15,2) NOT NULL,
  `discount` decimal(5,2) DEFAULT 0.00,
  `qty` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaksi_id` (`transaksi_id`),
  KEY `produk_id` (`produk_id`),
  CONSTRAINT `fk_detail_transaksi` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_detail_produk` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default data: Kasir admin
INSERT INTO `kasir` (`username`, `email`, `password`) VALUES
('admin', 'admin@doksstore.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Default data: Kategori
INSERT INTO `kategori` (`nama`, `alias`) VALUES
('Minuman', 'MIN'),
('Makanan', 'MKN'),
('Snack', 'SNK'),
('Rokok', 'ROK'),
('Kebersihan', 'KBR');

-- Default data: Produk contoh
INSERT INTO `produk` (`name`, `sku`, `discount`, `kategori_id`, `berat`, `price`, `stock`, `sold`) VALUES
('Aqua Botol', 'MIN-AquaBottle-600', 0.00, 1, 600, 4000, 100, 0),
('Indomie Goreng', 'MKN-IndomieGoreng-85', 0.00, 2, 85, 3500, 50, 0),
('Lays Original', 'SNK-LaysOriginal-68', 5.00, 3, 68, 12000, 30, 0),
('Gudang Garam Merah', 'ROK-GudangGaramMerah-12', 0.00, 4, 12, 22000, 20, 0),
('Sabun Lifebuoy', 'KBR-SabunLifebuoy-85', 0.00, 5, 85, 8500, 40, 0);
