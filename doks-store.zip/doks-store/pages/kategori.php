<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Kategori';
$db = getDB();

$error = ''; $success = '';

// CRUD Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $nama = cleanRaw($_POST['nama'] ?? '');
        $alias = strtoupper(cleanRaw($_POST['alias'] ?? ''));
        if (empty($nama) || empty($alias)) {
            $error = 'Nama dan alias wajib diisi.';
        } elseif (strlen($alias) !== 3) {
            $error = 'Alias harus tepat 3 karakter.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM kategori WHERE alias='$alias'");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Alias sudah digunakan.';
            } else {
                mysqli_query($db, "INSERT INTO kategori (nama, alias) VALUES ('$nama', '$alias')");
                $success = 'Kategori berhasil ditambahkan.';
            }
        }
    } elseif ($action === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        $nama = cleanRaw($_POST['nama'] ?? '');
        $alias = strtoupper(cleanRaw($_POST['alias'] ?? ''));
        if (empty($nama) || empty($alias)) {
            $error = 'Nama dan alias wajib diisi.';
        } elseif (strlen($alias) !== 3) {
            $error = 'Alias harus tepat 3 karakter.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM kategori WHERE alias='$alias' AND id != $id");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Alias sudah digunakan.';
            } else {
                mysqli_query($db, "UPDATE kategori SET nama='$nama', alias='$alias' WHERE id=$id");
                $success = 'Kategori berhasil diperbarui.';
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $chk = mysqli_query($db, "SELECT id FROM produk WHERE kategori_id=$id LIMIT 1");
        if (mysqli_num_rows($chk) > 0) {
            $error = 'Kategori masih digunakan oleh produk.';
        } else {
            mysqli_query($db, "DELETE FROM kategori WHERE id=$id");
            $success = 'Kategori berhasil dihapus.';
        }
    }
}

// Fetch all
$search = cleanRaw($_GET['q'] ?? '');
$where = $search ? "WHERE nama LIKE '%$search%' OR alias LIKE '%$search%'" : '';
$kategoris = mysqli_query($db, "SELECT k.*, (SELECT COUNT(*) FROM produk p WHERE p.kategori_id=k.id) as produk_count FROM kategori k $where ORDER BY k.nama ASC");

include __DIR__ . '/../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="card">
  <div class="card-header">
    <span class="card-title">Daftar Kategori</span>
    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
      <form method="GET" style="display:flex; gap:8px;">
        <input type="text" name="q" class="form-control" placeholder="Cari kategori..." value="<?= htmlspecialchars($search) ?>" style="width:200px;">
        <button type="submit" class="btn btn-secondary btn-sm">Cari</button>
        <?php if ($search): ?><a href="?" class="btn btn-secondary btn-sm">Reset</a><?php endif; ?>
      </form>
      <button class="btn btn-primary btn-sm" onclick="openModal('modalAdd')">+ Tambah Kategori</button>
    </div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr><th>#</th><th>Nama Kategori</th><th>Alias (SKU)</th><th>Jumlah Produk</th><th>Dibuat</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php $no=1; while ($k = mysqli_fetch_assoc($kategoris)): ?>
        <tr>
          <td style="color:var(--text-muted);"><?= $no++ ?></td>
          <td style="font-weight:600;"><?= htmlspecialchars($k['nama']) ?></td>
          <td><span class="badge badge-gold" style="font-family:'Cormorant Garamond',serif; letter-spacing:1px;"><?= htmlspecialchars($k['alias']) ?></span></td>
          <td><?= $k['produk_count'] ?> produk</td>
          <td style="font-size:0.8rem; color:var(--text-muted);"><?= date('d/m/Y', strtotime($k['created_at'])) ?></td>
          <td>
            <div style="display:flex; gap:6px;">
              <button class="btn btn-sm btn-outline" onclick="openEditModal(<?= $k['id'] ?>, '<?= addslashes(htmlspecialchars($k['nama'])) ?>', '<?= $k['alias'] ?>')">Edit</button>
              <form method="POST" onsubmit="return confirm('Hapus kategori ini?');" style="display:inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $k['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endwhile; ?>
        <?php if ($no === 1): ?>
        <tr><td colspan="6"><div class="empty-state"><div class="empty-icon">◈</div><h3>Tidak ada kategori</h3></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Add -->
<div class="modal-overlay" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Tambah Kategori</span>
      <button class="modal-close" onclick="closeModal('modalAdd')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Kategori</label>
          <input type="text" name="nama" class="form-control" placeholder="Contoh: Minuman" required>
        </div>
        <div class="form-group">
          <label class="form-label">Alias (3 karakter untuk SKU)</label>
          <input type="text" name="alias" class="form-control" placeholder="Contoh: MIN" maxlength="3" style="text-transform:uppercase;" required>
          <span class="form-hint">Alias digunakan sebagai prefix SKU produk. Contoh: MIN, MKN, SNK</span>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalAdd')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal-overlay" id="modalEdit">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Edit Kategori</span>
      <button class="modal-close" onclick="closeModal('modalEdit')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="editId">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Kategori</label>
          <input type="text" name="nama" id="editNama" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Alias (3 karakter)</label>
          <input type="text" name="alias" id="editAlias" class="form-control" maxlength="3" style="text-transform:uppercase;" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalEdit')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
      </div>
    </form>
  </div>
</div>

<?php
$extraScript = '<script>
function openEditModal(id, nama, alias) {
  document.getElementById("editId").value = id;
  document.getElementById("editNama").value = nama;
  document.getElementById("editAlias").value = alias;
  openModal("modalEdit");
}
document.querySelectorAll("input[style*=uppercase]").forEach(function(el) {
  el.addEventListener("input", function() { this.value = this.value.toUpperCase(); });
});
</script>';
include __DIR__ . '/../includes/footer.php';
?>
