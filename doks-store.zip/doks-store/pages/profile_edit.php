<?php
require_once __DIR__ . '/../config.php';
requireLogin();
$pageTitle = 'Edit Profile';
$db = getDB();
$kasir = getCurrentKasir();
$id = $kasir['id'];

$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $username = cleanRaw($_POST['username'] ?? '');
        $email = cleanRaw($_POST['email'] ?? '');
        
        if (empty($username) || empty($email)) {
            $error = 'Username dan email wajib diisi.';
        } elseif (strlen($username) < 3) {
            $error = 'Username minimal 3 karakter.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Format email tidak valid.';
        } else {
            $chk = mysqli_query($db, "SELECT id FROM kasir WHERE (username='$username' OR email='$email') AND id != $id");
            if (mysqli_num_rows($chk) > 0) {
                $error = 'Username atau email sudah digunakan.';
            } else {
                mysqli_query($db, "UPDATE kasir SET username='$username', email='$email' WHERE id=$id");
                $_SESSION['kasir_username'] = $username;
                $kasir = getCurrentKasir();
                $success = 'Profile berhasil diperbarui.';
            }
        }
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $newpass = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        
        if (empty($current) || empty($newpass) || empty($confirm)) {
            $error = 'Semua field password wajib diisi.';
        } elseif ($newpass !== $confirm) {
            $error = 'Password baru tidak cocok.';
        } elseif (strlen($newpass) < 6) {
            $error = 'Password baru minimal 6 karakter.';
        } else {
            $res = mysqli_query($db, "SELECT password FROM kasir WHERE id=$id");
            $row = mysqli_fetch_assoc($res);
            if (!password_verify($current, $row['password'])) {
                $error = 'Password saat ini tidak benar.';
            } else {
                $hash = password_hash($newpass, PASSWORD_DEFAULT);
                mysqli_query($db, "UPDATE kasir SET password='$hash' WHERE id=$id");
                $success = 'Password berhasil diubah.';
            }
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div style="max-width:640px;">
  <div style="margin-bottom:16px;">
    <a href="<?= BASE_URL ?>/pages/profile.php" class="btn btn-secondary btn-sm">← Kembali ke Profile</a>
  </div>
  
  <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
  
  <!-- Edit Profile Info -->
  <div class="card" style="margin-bottom:20px;">
    <div class="card-header">
      <span class="card-title">Informasi Akun</span>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="update_profile">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($kasir['username']) ?>" required minlength="3">
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($kasir['email']) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
      </form>
    </div>
  </div>
  
  <!-- Change Password -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">Ganti Password</span>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="action" value="change_password">
        <div class="form-group">
          <label class="form-label">Password Saat Ini</label>
          <input type="password" name="current_password" class="form-control" placeholder="Masukkan password saat ini" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password Baru</label>
          <input type="password" name="new_password" class="form-control" placeholder="Minimal 6 karakter" required>
        </div>
        <div class="form-group">
          <label class="form-label">Konfirmasi Password Baru</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="Ulangi password baru" required>
        </div>
        <button type="submit" class="btn btn-primary">Ganti Password</button>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
