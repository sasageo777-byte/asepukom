    </div><!-- /content-area -->
  </div><!-- /main-content -->
</div><!-- /app-wrapper -->

<script>
// Sidebar toggle
function toggleSidebar() {
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('sidebarOverlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('show');
}

// Topbar date
function updateDate() {
  var el = document.getElementById('topbarDate');
  if (!el) return;
  var d = new Date();
  var days = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
  var months = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
  el.textContent = days[d.getDay()] + ', ' + d.getDate() + ' ' + months[d.getMonth()] + ' ' + d.getFullYear();
}
updateDate();

// Modal helpers
function openModal(id) {
  var m = document.getElementById(id);
  if (m) { m.classList.add('show'); document.body.style.overflow = 'hidden'; }
}

function closeModal(id) {
  var m = document.getElementById(id);
  if (m) { m.classList.remove('show'); document.body.style.overflow = ''; }
}

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(function(overlay) {
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) closeModal(overlay.id);
  });
});

// Alert dismiss
document.querySelectorAll('.alert-dismiss').forEach(function(btn) {
  btn.addEventListener('click', function() {
    this.parentElement.remove();
  });
});
</script>
<?php if (isset($extraScript)) echo $extraScript; ?>
</body>
</html>
